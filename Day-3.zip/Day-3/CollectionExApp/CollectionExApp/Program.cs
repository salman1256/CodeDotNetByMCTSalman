﻿//using System;
//using System.Collections;


//namespace CollectionExApp
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            ArrayList arrayList = new ArrayList
//            {
//                "Sam",
//                "Raj",
//                "Deep"
//            };
//            //Console.WriteLine("Number of items inside ArrayList: "+arrayList.Count);
//            //Console.WriteLine("Capacity of arrayList is: "+arrayList.Capacity);
//            //Console.WriteLine("---Stored Values---");
//            //foreach (var item in arrayList)
//            //{
//            //    Console.WriteLine(item);
//            //}
//            //arrayList.Add("Rahul");
//            //arrayList.Add("Sam");

//            //arrayList.Sort();
//            //Console.WriteLine("-----------Sorted Name List -----");
//            //foreach (var item in arrayList)
//            //{
//            //    Console.WriteLine(item);
//            //}
//            //Console.WriteLine("-----------Sorted Name List in Desc -----");
//            //arrayList.Reverse();
//            //foreach (var item in arrayList)
//            //{
//            //    Console.WriteLine(item);
//            //}
//            arrayList.Insert(1, "Jai");
//            Console.WriteLine("After Inserting Item at index 1");
//            foreach (var item in arrayList)
//            {
//                Console.WriteLine(item);
//            }
//            arrayList.RemoveAt(2);
//            Console.WriteLine("After Removing from Index 2");
//            foreach (var item in arrayList)
//            {
//                Console.WriteLine(item);
//            }
//            Console.ReadKey();
//        }
//    }
//}
//using System;
//using System.Collections;
//namespace CollectionExApp
//{
//    public class UserDesk
//    {

//        public static void Main()
//        {
//            ArrayList empList = new ArrayList
//            { 
//            new Emp
//            { Id=1,Name="Sam",Designation="Manager",Salary=99000.789,
//                DOJ=DateTime.Now
//            },
//            new Emp
//            { Id=2,Name="Raj",Designation="Manager",Salary=99000.5005,
//                DOJ=new DateTime(day:12,month:10,year:2020)
//            },
//            new Emp
//            { Id=5,Name="Vipin",Designation="Developer",Salary=93000.99,
//             DOJ=new DateTime(day:24,month:02,year:2018)
//            },
//            new Emp
//            { Id=6,Name="Ruhee",Designation="Developer",Salary=97000.99
//            , DOJ=new DateTime(day:06,month:04,year:2019)
//            },
//            new Emp
//            { Id=8,Name="Zoya",Designation="HR",Salary=68000.99,
//             DOJ=new DateTime(day:30,month:08,year:2018)
//            },
//            };
//            Console.WriteLine("----------Employees List---------");
//            Console.WriteLine("Index \t ID \t Name \t \t Designation \t \t Salary \t \t Date of Joining");
//            //foreach (Emp emp in empList)
//            //{
//            //    Console.Write(empList.IndexOf(emp)+"\t");
//            //    Console.Write(emp.Id +"\t");
//            //    Console.Write(emp.Name + "\t");
//            //    Console.Write("\t"+emp.Designation + "\t");
//            //    Console.Write("\t"+emp.Salary + "\t");
//            //    Console.Write("\t"+emp.DOJ.ToShortDateString() );
//            //    Console.WriteLine("\n");
//            //}
//            for (int i = 0; i < empList.Count; i++)
//            {
//                Console.Write(i + "\t");
//                Console.Write(((Emp)empList[i]).Id + "\t");
//                Console.Write(((Emp)empList[i]).Name + "\t");
//                Console.Write("\t" + ((Emp)empList[i]).Designation + "\t");
//                Console.Write("\t" + ((Emp)empList[i]).Salary + "\t");
//                Console.Write("\t" + ((Emp)empList[i]).DOJ.ToShortDateString());
//                Console.WriteLine("\n");
//            }
//            Console.ReadKey();
//        }
//    }
//}
//Exmaple-3
//using System;
//using System.Collections;
//namespace CollectionExApp
//{
//    public class Program
//    {
//        public static void Main()
//        {
//            //Hashtable hashtable = new Hashtable
//            //{
//            //    {1,"Sam" },
//            //    { 2,"Raj"},
//            //    { 3,"Amit"},
//            //    { 5,"Vinay"},
//            //    { 9,"Rohan"}
//            //};
//            //Console.WriteLine("Key \t Values");
//            //foreach (var k in hashtable.Keys)
//            //{
//            //    Console.WriteLine(k +"\t"+hashtable[k]);
//            //}
//            Hashtable hashtable = new Hashtable
//            {
//                {"hdd","Hard Disc" },
//                { "fdd","Floppy Disc"},
//                { "kb","Kilo Bytes"},
//                { "mb","Mega Bytes"},
//                { "gb","Giga Bytes"}
//            };
//            Console.WriteLine("Key \t Values");
//            foreach (var k in hashtable.Keys)
//            {
//                Console.WriteLine(k + "\t" + hashtable[k]);
//            }
//            //Console.WriteLine("Enter Key to find full form");
//            //string sKey = Console.ReadLine();
//            //if (hashtable.ContainsKey(sKey))
//            //{
//            //    Console.WriteLine("Full Form of {0} is = \t {1}", sKey, hashtable[sKey]);
//            //}
//            //else
//            //{
//            //    Console.WriteLine("No such key {0} found in Collection",sKey);
//            //}

//            Console.WriteLine("Enter Key To Insert ");
//            string nKey = Console.ReadLine();
//            if (!hashtable.ContainsKey(nKey))
//            {
//                Console.WriteLine("Enter Full Form ");
//                string nValue = Console.ReadLine();
//                hashtable.Add(nKey, nValue);
//                Console.WriteLine("Update Hash Table as follows");
//                Console.WriteLine("Key \t Values");
//                foreach (var k in hashtable.Keys)
//                {
//                    Console.WriteLine(k + "\t" + hashtable[k]);
//                }
//            }
//            else
//            {
//                Console.WriteLine("The key {0} already exist in Collection", nKey);
//            }
//            Console.ReadKey();
//        }
//    }
//}
//Example-3
//using System;
//using System.Collections;
//namespace CollectionExApp
//{    public class Program
//    {
//        public static void Main()
//        {

//           SortedList sortedList= new SortedList
//            {
//                {"hdd","Hard Disc" },
//                { "fdd","Floppy Disc"},
//                { "kb","Kilo Bytes"},
//                { "mb","Mega Bytes"},
//                { "gb","Giga Bytes"}
//            };
//            Console.WriteLine("Index :-> Key");
//            foreach(var k in sortedList.Keys )
//            {
//                Console.WriteLine(sortedList.IndexOfKey(k)+" :-> "+k);
//            }
//            Console.WriteLine("Index:-> Values ");
//            foreach (var v in sortedList.Values)
//            {
//                Console.WriteLine(sortedList.IndexOfValue(v)+" :-> "+v);
//            }
//            Console.WriteLine("Index \t Key  \t Value");
//            foreach (var k in sortedList.Keys)
//            {
//                Console.WriteLine(sortedList.IndexOfKey(k) + " \t " + k +"\t "+sortedList[k]);
//            }
//            sortedList.Clear();
//            Console.WriteLine("After Clear Number of Items: "+sortedList.Count);
//            Console.WriteLine("Index \t Key  \t Value");
//            foreach (var k in sortedList.Keys)
//            {
//                Console.WriteLine(sortedList.IndexOfKey(k) + " \t " + k + "\t " + sortedList[k]);
//            }

//            //Console.WriteLine("Key \t Values");
//            //foreach (var k in sortedList.Keys)
//            //{
//            //    Console.WriteLine(k + "\t" + sortedList[k]);
//            //}

//            Console.ReadKey();
//        }
//    }
//}
//Example-4
using System;
using System.Collections;
namespace CollectionExApp
{
    public class Program
    {
        public static void Main()
        {

            //Stack stack = new Stack();
            //stack.Push("Aman");
            //stack.Push("Deep");
            //stack.Push("Raj");
            //stack.Push("Vinay");
            //stack.Push("Vinod");
            //Console.WriteLine("Items inside stacks are: "+stack.Count);
            //foreach (var item in stack)
            //{ Console.WriteLine(item); }
            //stack.Pop();
            //Console.WriteLine("After 1 Removing item from Stack");
            //Console.WriteLine("Items inside stacks are: " + stack.Count);
            //foreach (var item in stack)
            //{ Console.WriteLine(item); }
            //Console.WriteLine(stack.Peek());
            //Console.WriteLine(" After Peek Items inside stacks are: " + stack.Count);

            //Console.ReadKey();

            Queue queue = new Queue();
            queue.Enqueue("Aman");
            queue.Enqueue("Deep");
            queue.Enqueue("Raj");
            queue.Enqueue("Vinay");
            queue.Enqueue("Vinod");
            Console.WriteLine("Items inside queues are: " + queue.Count);
            foreach (var item in queue)
            { Console.WriteLine(item); }
            queue.Dequeue();
            Console.WriteLine("After 1 Removing item from queue");
            Console.WriteLine("Items inside queues are: " + queue.Count);
            foreach (var item in queue)
            { Console.WriteLine(item); }
            Console.WriteLine(queue.Peek());
            Console.WriteLine(" After Peek Items inside queues are: " + queue.Count);

            Console.ReadKey();
        }
    }
}