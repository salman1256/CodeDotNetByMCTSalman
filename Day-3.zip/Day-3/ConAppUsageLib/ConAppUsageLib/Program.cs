﻿using System;
using CalcLib;
namespace ConAppUsageLib
{   public class MyClass : Calculator
    {
        public void Display()
        { 
            Console.WriteLine("Name: "+this.Name);
        }
    }
    public static class OurClass
    {
        public static void Welcome(this Calculator obj)
        {
            Console.WriteLine("Welcome to our Calculator Library!!!");
        }
        public static double MaxNum(this Calculator ob, double n1, double n2)
        {
            double maxNum;
            if (n1 == n2)
            {
                Console.WriteLine("{0} and {1} Both are equal", n1, n2);
                maxNum = 0;
            }
            else if (n1 > n2)
            {
                maxNum = n1;
            }
            else { maxNum = n2; }
            return maxNum;

        }
    }

    class Program
    {        static void Main(string[] args)
        {
            
            double num1, num2;
            string choice;
            Calculator calc = new Calculator();
            //Calculator.Welcome(); Error
           // OurClass.Welcome(calc);
            calc.Welcome();
            do {
                Console.WriteLine("Enter First Number ");
                num1 = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter Second Number ");
                num2 = double.Parse(Console.ReadLine());
                Console.WriteLine
               ("Choose operation \n 1.Add \n 2.Multi \n 3. Div \n 4. Difference \n 5. Avg \n 6. Maximum ");
                int op = int.Parse(Console.ReadLine());
                
                switch (op)
                {
                    default:
                        {    Console.WriteLine("Invalid Operation Choice!!");
                            break; }
                    case 1:
                        {
                            Console.WriteLine("Result after adding {0} and {1} = \t {2} "
                                ,num1,num2,calc.Add(num1,num2));
                            break; }
                    case 2:
                        {
                            Console.WriteLine("Result after multiplying {0} and {1} = \t {2} "
                                  , num1, num2, calc.Multi(num1, num2));
                            break; }
                    case 3:
                        {
                            Console.WriteLine("Result after Dividing {0} by {1} = \t {2} "
                                    , num1, num2, calc.Div(num1, num2));

                            break; }
                    case 4:
                        {
                            Console.WriteLine("Result after subtracting {1} from {0} = \t {2} "
                                 , num1, num2, calc.Diff(num1, num2));
                            break; }
                    case 5:
                        {
                            Console.WriteLine("Average of  {0} and {1} = \t {2} "
                                 , num1, num2, calc.Avg(num1, num2));
                            break; }
                    case 6:
                        {
                            Console.WriteLine("Maximum of  {0} and {1} = \t {2} "
                                 , num1, num2, calc.MaxNum(num1, num2));
                            break;
                        }

                }

                Console.WriteLine("To Continue Press y \n To Exit Press Any Other Key");
                choice = Console.ReadLine().ToLower();
            }
            while (choice == "y");
        }
    }
}
