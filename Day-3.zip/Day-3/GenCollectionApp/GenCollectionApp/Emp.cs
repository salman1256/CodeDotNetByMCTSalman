﻿using System;
namespace GenCollectionApp
{
    public class Emp
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime DOB{ get; set; }
    }
}
