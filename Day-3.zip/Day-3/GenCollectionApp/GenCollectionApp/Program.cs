﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenCollectionApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //List<string> nameList = new List<string> { 
            //"Sam",
            //"Ravi",
            //"Nitin"};
            //Console.WriteLine("Names inside List are: "+nameList.Count);
            //Console.WriteLine("Capacity of List is: "+nameList.Capacity);
            //foreach (string n in nameList)
            //{
            //    Console.WriteLine(n);
            //}
            //nameList.Add("Deep");
            //nameList.Add("Rahul");
            //nameList.Add(12.ToString());
            //Console.WriteLine("After Adding Two more names");
            //Console.WriteLine("Names inside List are: " + nameList.Count);
            //Console.WriteLine("Capacity of List is: " + nameList.Capacity);
            //nameList.Sort();
            //foreach (string n in nameList)
            //{
            //    Console.WriteLine(n);
            //}
            //Console.ReadKey();
            List<Emp> empList = new List<Emp>()
            {
            new Emp{ Id=1,Name="Sam",DOB=new DateTime (day:10,year:1987,month:12)},
             new Emp{ Id=2,Name="Pinky",DOB=new DateTime (day:10,year:1987,month:06)},
              new Emp{ Id=4,Name="Neeraj",DOB=new DateTime (day:10,year:2000,month:02)},
               new Emp{ Id=5,Name="Viru",DOB=new DateTime (day:08,year:1990,month:10)},
                new Emp{ Id=8,Name="Deep",DOB=new DateTime (day:07,year:1999,month:11)},
            };
            //Console.WriteLine("ID \t Name \t Date of Birth");
            //for (int i = 0; i < empList.Count; i++)
            //{
            //    Console.Write(empList[i].Id+"\t");
            //    Console.Write(empList[i].Name + "\t");
            //    Console.Write(empList[i].DOB.ToLongDateString() + "\t");
            //    Console.WriteLine("\n");
            //}
            Console.WriteLine("ID \t Name \t Date of Birth");
            foreach (var emp in empList)
            {
                Console.Write(emp.Id + "\t");
                Console.Write(emp.Name + "\t");
                Console.Write(emp.DOB.ToLongDateString() + "\t");
                Console.WriteLine("\n");
            }
            Console.ReadKey();
            //Dictionary<int,string>
           // SortedList<int,string>
          // Queue<string>
          //Stack <string>


        }
    }
}
