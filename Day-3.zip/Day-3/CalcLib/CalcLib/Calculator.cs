﻿namespace CalcLib
{
    public class Calculator

    {
         string name="mathCalculator";
          protected internal string  Name { get { return name; } }
        public double Add(double n1, double n2)
        {
            double result = n1 + n2;
            return result;
        }
        public double Diff(double n1, double n2)
        {
            double result = n1 - n2;
            return result;
        }
        public double Avg(double n1, double n2)
        {
            double result = (n1 + n2)/2;
            return result;
        }
        public double Multi(double n1, double n2)
        {
            double result = n1 * n2;
            return result;
        }
        public double Div(double n1, double n2)
        {
            double result = n1 / n2;
            return result;
        }
    }
}
