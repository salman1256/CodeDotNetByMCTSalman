﻿using System;
using Toshiba;
using Dell;
namespace SamSung
{
    class Program
    {
        static void Main(string[] args)
        {
            //Toshiba.Laptop objLp = new Toshiba.Laptop();
            Dell.Laptop objLp = new Dell.Laptop();
            Toshiba.Laptop toshibLp = new Toshiba.Laptop();
            Mobile mob = new Mobile();
            objLp.Display();
            toshibLp.Display();
             mob.Display();
            Console.ReadKey();
        }
    }
}

namespace Toshiba
{
    public class Laptop
    {
        public void Display()
        { Console.WriteLine("-----Toshiba Laptop Display---"); } }
}