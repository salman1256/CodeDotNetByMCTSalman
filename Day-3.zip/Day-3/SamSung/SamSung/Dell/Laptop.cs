﻿using System;
namespace Dell
{
   public class Laptop
    {
        public void Welcome()
        { 
            Console.WriteLine("Welcome to Dell Laptop!!!"); 
        }
        public void Display()
        { Console.WriteLine("Dell Laptop Display"); }
    }
    public class Mobile
    {
        public void Display()
        { Console.WriteLine("Future Mobile by Dell Display!!!"); }
    }
}
