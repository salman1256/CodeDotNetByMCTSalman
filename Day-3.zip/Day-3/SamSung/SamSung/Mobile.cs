﻿using System;
namespace SamSung
{
    public class Mobile
    {
        public void Display()
        {
            Console.WriteLine("---Samsung Mobile Display---");
        }
    }
}
