﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExOne
{
    public interface Interface2
    {
       void Second();
        void Display();
    }
}
