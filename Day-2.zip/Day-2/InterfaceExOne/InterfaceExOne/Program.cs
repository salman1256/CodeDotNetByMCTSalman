﻿using System;

namespace InterfaceExOne
{
    public class OurClass : Interface1,Interface2
    {
        string myField;
        public string MyProp { get =>myField ; set => myField=value; }

        void Interface1.Display()
        {
            Console.WriteLine("Welcome to Interface1 Display Method in ");
        }
        
        public void Second()
        {
            Console.WriteLine("Second Method of interface"); ;
        }

        void Interface2.Display()
        {
            Console.WriteLine("Interface two Display Method!!!");
        }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            OurClass obj = new OurClass();
            //obj.Interface1.Display();
            Interface2 ob = obj;

            ob.Display();
            Console.ReadKey();
        }
    }
}
