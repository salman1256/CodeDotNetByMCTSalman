﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAbstractClassesEx
{
    class Program
    {
        static void Main(string[] args)
        {
            //OurAbClass ourAb = new OurAbClass(); //Error can't instantiate abstract class
            OurChClass chClass = new OurChClass();
            chClass.Display();
            chClass.OurAbProp = "I'm live!!!";
            Console.WriteLine(chClass.Welcome("Raj Kumar Vats"));
            Console.WriteLine("Non Abstract Prop : "+chClass.OurProp);
            Console.WriteLine("Ab prop Call "+chClass.OurAbProp);
            Console.ReadKey();

        }
    }
}
