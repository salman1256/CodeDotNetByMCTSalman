﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAbstractClassesEx
{
   public abstract class OurAbClass
    {
        readonly int ourField;
        public OurAbClass()
        {
            Console.WriteLine("Abstract Constructor!!!");
            ourField = 12;
        }
        public void Display()
        {
            Console.WriteLine("Non Abstract Method inside Abstract Class");
        }
        public int OurProp
        {
            get { return ourField; }
        }
        public abstract string Welcome(string name);
        public abstract string OurAbProp { get; set; }
    }
}
