﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAbstractClassesEx
{
    public class OurChClass : OurAbClass
    {
        string chFiled;
        public override string OurAbProp { get =>chFiled; set =>chFiled=value; }
        public override string Welcome(string name)
        {
            return "Welcome to Abstract Classes Mr.\\Mrs.\\Miss :"+name;
        }
    }
}
