﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiLevelInheritanceEx
{
    public class Emp
    {
        readonly int id;
        readonly string name;
        public Emp(int id,string name)
        {
            this.id = id;
            this.name = name;
        }
        public virtual void Display()
        {
            Console.WriteLine("ID: \t "+id);
            Console.WriteLine("Name: \t "+name);
        }
    }
}
