﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiLevelInheritanceEx
{
    class Program
    {
        static void Main(string[] args)
        {
            AppDev appDev = new AppDev(12,"Sam",".net","android");
            appDev.Display();
            Console.ReadKey();
        }
    }
}
