﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiLevelInheritanceEx
{
    public class OurTest:AppDev
    {
        public OurTest(int id,string name,string domain,string osType):base(id,name,domain,osType)
        {

        }
       // public override  void Display()
       // { }
    }
}
