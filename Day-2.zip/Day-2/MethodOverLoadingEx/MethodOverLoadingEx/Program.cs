﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverLoadingEx
{    public class OurClass
    { 
        public void Display()
        {
            Console.WriteLine("Display Method!!!");
        }
        public void Display(int id)
        {
            Console.WriteLine("Your Id is "+id);
        }
        public void Display(string name)
        {
            Console.WriteLine("Welcome to Method OverLoading " + name);
        }
        public void Incr(int num)
        {
            Console.WriteLine("Before Increment \t "+num);
            num++;
            Console.WriteLine("After Increment \t " + num);
        }
        //public void Incr(ref int num)
        //{
        //    Console.WriteLine("Before Increment \t " + num);
        //    num++;
        //    Console.WriteLine("After Increment \t " + num);
        //}
        public void Incr(out int num)
        {
            num = 10;
            Console.WriteLine("Before Increment \t " + num);
            num++;
            Console.WriteLine("After Increment \t " + num);
        }
        public void Display(string name, int id)
        {
            Console.WriteLine("Person Name: \t"+name);
            Console.WriteLine("Person ID: \t" + id);
        }
        public void Display( int id,string name)
        {
            Console.WriteLine("Department ID : \t " + id);
            Console.WriteLine("Department Name : \t" + name);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            OurClass obj = new OurClass();
            //obj.Display(id:12,name:"R");
            Console.ReadKey();
        }
    }
}
