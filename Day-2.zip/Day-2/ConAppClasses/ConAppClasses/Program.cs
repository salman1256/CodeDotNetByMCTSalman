﻿using System;
namespace ConAppClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            //Emp emp = new Emp();
            //Emp emp1 = new Emp();
            //Dev objdev = new Dev();
            //emp.Register();
            //objdev.Register();
            //emp.Display();
            //emp1.Display();
            //objdev.Display();
            //Console.ReadKey();
            //Example-Two
            //Emp objemp = new Emp(12,"Sameer");
            //objemp.Display();
            Dev dev = new Dev(13, "Rajesh Negi", "Java Full Stack", "e-educate_universe");
            dev.Display();
            Console.ReadKey();
        }
    }
}
