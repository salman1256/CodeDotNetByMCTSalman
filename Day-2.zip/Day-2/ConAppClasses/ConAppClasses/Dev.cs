﻿//using System;

//namespace ConAppClasses
//{
//   public class Dev:Emp
//    {
//        string domain;
//        string projects;
//        public Dev()
//        {
//            Console.WriteLine("Developer Constructor!!!");
//            domain = "not given";
//            projects = "not assign";

//        }
//        public override void Display()
//        {
//            base.Display();
//            Console.WriteLine("Domain: \t "+domain);
//            Console.WriteLine("Projects: \t "+projects);
//        }
//        public override void Register()
//        {
//            base.Register();
//            Console.WriteLine("Enter Domain");
//            domain = Console.ReadLine();
//            Console.WriteLine("Enter Projects");
//            projects = Console.ReadLine();
//        }
//    }
//}
using System;

namespace ConAppClasses
{
    public class Dev : Emp
    {
        string domain;
        string projects;
        public Dev(int id, string name, string dom, string pro):base(id,name)
        {
            Console.WriteLine("Developer Constructor Call");
            domain = dom;
            projects = pro;

        }
        public override void Display()
        {
            Console.WriteLine( "----Developer Details---");
            base.Display();
            Console.WriteLine("Domain \t "+domain);
            Console.WriteLine("Projects: \t "+projects);
        }

    }
}