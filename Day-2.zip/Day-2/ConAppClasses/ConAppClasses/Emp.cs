﻿//using System;

//namespace ConAppClasses
//{    public class Emp
//    {   int eid;
//        string ename;
//        public Emp()
//        {  Console.WriteLine("----Emp Constructor-----");
//            eid = -1;
//            ename = "not given";
//                    }
//        public virtual void Register()
//        {
//            Console.WriteLine("Enter ID :");
//            eid = int.Parse(Console.ReadLine());
//            Console.WriteLine("Enter Name :");
//            ename = Console.ReadLine();
//        }
//        public virtual void Display()
//        {
//            Console.WriteLine("ID: \t "+eid);
//            Console.WriteLine("Name: \t "+ename);
//        }
//    }
//}
using System;

namespace ConAppClasses
{
    public class Emp
    {
        readonly int eid;
        readonly string ename;
        public Emp(int id,string name)
        {
            Console.WriteLine("Employee Constructor Call");
            //this.eid = eid;
            //this.ename = ename;
            eid = id;
            ename = name;
        }
        
        public virtual void Display()
        {
           
            Console.WriteLine("ID: \t " + eid);
            Console.WriteLine("Name: \t " + ename);
        }
    }
}
