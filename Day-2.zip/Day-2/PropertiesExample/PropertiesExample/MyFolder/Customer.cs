﻿using System;

namespace PropertiesExample
{
    public partial class Customer
    {
        public Customer()
        {
            Console.WriteLine("Customer Class Constructor!!!");
        }
    }
}
