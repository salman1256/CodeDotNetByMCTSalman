﻿//using System;
//namespace PropertiesExample
//{
//   // [A.S.][Modifier] DataType PropertyName {get {//return ;} set { //value;}}
//   //ReadOnly :get
//   //WriteOnly:set
//   //ReadAndWrite: get,set
//   //static :
//   //AutoImplement:
//   //abstract
//    public class Customer
//    {   private int cid;
//        private string cname;
//        private string ccity;
//        private readonly double cODLimit;
//        private  static double tax=12.45;
//        public Customer()
//        {   cid = -1;
//            cname = "not given";
//            ccity = "not given";
//            cODLimit =550000.50;
//                    }
//        public  int Id {
//            get { 
//                if (cid == -1)
//            { Console.WriteLine("Invalid Id");
//                return cid;
//            }
//            else
//            { return cid; } 
//            }
//            set {
//                if (value >= 1)
//                { cid = value; }
//                else { cid = -1; }
//            } }
//        public string  Name { get { return cname; } set { cname = value; } }
//        public string City { get { return ccity; } set { ccity = value; } }
//        public double ODLimit { get { return cODLimit; } } //ReadOnly
//        public static double Tax { get { return tax; } set { tax = value; } } //static
//    } }
using System;
namespace PropertiesExample
{
    public partial class Customer
    {
        public int Id { get; set; }
        public  string Name { get; set; }
        public DateTime MStartDate { get; set; }
    }
}