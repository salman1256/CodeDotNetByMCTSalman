﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesExample
{
    class Program
    {
        static void Main(string[] args)
        {
            //Customer customer = new Customer();
            //Console.WriteLine("Enter Customer Id");
            //customer.Id = int.Parse(Console.ReadLine());
            //customer.Name = "Sam";
            //customer.City = "Delhi";
            ////customer.ODLimit = 124000.90;//Error ReadOnly
            ////customer.Tax = 12.56; //For Whole Class not for the instance of the Class
            //Customer.Tax = 10.90;
            //Console.WriteLine("Customer ID : \t "+customer.Id);
            //Console.WriteLine("Customer Name: \t"+customer.Name);
            //Console.WriteLine("Customer City: \t" + customer.City);
            //Console.WriteLine("Customer OverDraft Limit: \t" + customer.ODLimit);
            //Console.WriteLine("Applicable Tax: \t"+Customer.Tax);
            //Console.ReadKey();
            //Second Example

            Customer objc = new Customer
            {
                Id = 1,
                Name = "Sam",
                MStartDate = new DateTime(day: 12, month: 06, year: 2021)
            };
            Console.WriteLine("------------Customer Details----------");
            Console.WriteLine(objc.Id+"->"+objc.Name+"->"+objc.MStartDate.ToShortDateString());
            Console.ReadKey();
        }
    }
}
