﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayEx
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[,] studMarks = new int[4, 3];
            //for(int i=0;i<4;i++)
            //{
            //    Console.WriteLine("Enter Student{0}\'s Roll Number",(i+1));
            //    studMarks[i, 0] = int.Parse(Console.ReadLine());
            //    for (int j = 1;j<3; j++)
            //    {
            //        Console.WriteLine("Enter Student {0}\'s Marks in Sem {1}",(i+1),j);
            //        studMarks[i, j] = int.Parse(Console.ReadLine());
            //    }
            //}
            //Console.WriteLine("RollNO \t Sem1 \t Sem2 ");
            //for (int i = 0; i < 4; i++)
            //{
            //    for (int j = 0; j < 3; j++)
            //    { Console.Write(studMarks[i,j]+"\t"); }
            //    Console.WriteLine("\n");
            //}
            //Console.ReadKey();

            //DataType[] ArrayName = new DataType[size]
            //DataType[,] ArrayName = new DataType[rows,cols]
            //DataType[][] ArrayName = new DataType[rows][]
            string[][] studJArray = new string[3][];
            studJArray[0] = new string[3] {"Sam","Amit","Vidhu" };
            studJArray[1] = new string[5] { "Anil", "Amit", "Vidhu","Anirudh","Gagan" };
            studJArray[2] = new string[2] { "Deep", "Neelam" };
            Console.WriteLine("Stored Values are ");
            for (int i = 0; i < studJArray.Length; i++)
            {
                for (int j = 0; j < studJArray[i].Length; j++)
                { 
                    Console.Write(studJArray[i][j]+"\t"); 
                }
                Console.WriteLine("\n");
            }
            Console.ReadKey();
        }
    }
}
