﻿using System;
namespace MethodinCS
{
    public class OurClass
    {
        public  void Display()
        {
            Console.WriteLine("Static Method void return Type no paramters");
        }
        public static string Welcome()
        {
            return "Welcome to Methods in C#";
        }
        public static string UserWelcome(string userName)
        {
            return "Welcome to Methods in C# Mr.\\Ms. "+userName;
        }
        public static void Add(double num1, double num2)
        {
            double result = num1 + num2;
            Console.WriteLine("Result after adding {0} and {1} is =  {2}\t ",num1,num2,result);
        }
    }
}
