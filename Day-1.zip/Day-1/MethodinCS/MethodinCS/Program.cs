﻿//using System;
//namespace MethodinCS
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            OurClass obj = new OurClass();
//            obj.Display();
//            Console.WriteLine(OurClass.Welcome());
//            Console.WriteLine(OurClass.UserWelcome("Sam"));
//            OurClass.Add(45, 67);
//            Console.ReadKey();
//        }
//    }
//}
//using System;
//namespace MethodinCS
//{public class SalaryCalc
//    {
//        public void Increment( ref double sal)
//        {
//            Console.WriteLine("Salary before Increment in Method is = \t"+sal);
//            sal += sal * 0.15;
//            Console.WriteLine("Salary after Increment in Method is = \t" + sal);

//        } 
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            double salary = 40000.40;
//            SalaryCalc calc = new SalaryCalc();
//            Console.WriteLine("Salary in Main before calling Increment \t "+salary);
//            calc.Increment(ref salary);
//            Console.WriteLine("Salary in Main after calling Increment \t " + salary);
//            Console.ReadKey();
//        }
//    }
//}
//using System;
//namespace MethodinCS
//{
//    public class SalaryCalc
//    {
//        public void CalBonus( double sal, out double bonus)
//        {
//            Console.WriteLine("Bonus calculation based on certain points!!!");
//             bonus= sal * 0.15;


//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            double salary = 40000.40;
//            double bonus;
//            SalaryCalc calc = new SalaryCalc();
//            calc.CalBonus( salary,out bonus);
//            Console.WriteLine("Updated Bonus is " + bonus);
//            Console.ReadKey();
//        }
//    }
//}
//using System;
//namespace OurMethodsParameter
//{
//    public class Calculator
//    {
//        public static double Add(params double[] nums)
//        {
//            double result = 0;
//            foreach (var n in nums)
//            {
//                result += n;
//            }
//            return result;
//        }
//        public static void Main()
//        {
//            Console.WriteLine("Result after adding 12,45.5,67.7 is= \t" + Add(12, 45.5, 67.7));
//            Console.WriteLine("Result after adding 0.5,0.5,0.6,0.6 is= \t" + Add(0.5, 0.5, 0.6, 0.6));
//            Console.WriteLine("Result after adding 1.5,2.5is= \t" + Add(1.5, 2.5));
//        }
//    }
//}
//using System;
//namespace OurMethodsParameter
//{
//    public class Calculator
//    {
//        public static int Add(int num1=10, int num2=30)
//        {
//            return num1 + num2; 
//        }
//        public static void Display(string fname,string lname, string city="Delhi", string country="India")
//        {
//            Console.WriteLine("Employee Details as  follows!!!");
//            Console.WriteLine("Full Name : "+fname +" "+lname);
//            Console.WriteLine("City : "+city);
//            Console.WriteLine("Country : "+country);
//        }
//        public static void Main()
//        {
//            Display("Sam","Dicosta");
//            Console.WriteLine("-------------------------------");
//            Display("Niharika", "Mohanti","Hyderabad");
//            Console.WriteLine("-------------------------------");
//            Display("Johan", "D.M.", "California","USA");
//            Console.ReadKey();

//        }
//    }
//}

using System;
namespace OurMethodsParameter
{
    public class OurClass
    {
       
        public static string FullName(string fname, string lname)
        {
            
           return "Full Name : " + fname + " " + lname;
            
        }
        public static void Main()
        {
            Console.WriteLine(FullName("Sam","Dicosta"));
            Console.WriteLine(FullName(lname:"Dicosta", fname:"Sam"));
            DateTime dt = new DateTime(day:25,month:12,year:2020);
            Console.WriteLine(dt.ToLongDateString());
            Console.ReadKey();

        }
    }
}