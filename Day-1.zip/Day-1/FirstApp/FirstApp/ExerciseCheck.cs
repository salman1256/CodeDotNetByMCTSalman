﻿//using System;
//namespace FirstApp
//{
//    class ExerciseCheck
//    {
//        public static void Main()
//        { 
//            int pMark, fMark;
//            Console.WriteLine("Candidate Selection:");
//            Console.WriteLine("Enter pre exam Mark");
//            pMark = int.Parse(Console.ReadLine());
//            if (pMark > 45)
//            {
//                Console.WriteLine("Enter Final Exam Mark");
//                fMark = int.Parse(Console.ReadLine());
//                if (fMark > 55)
//                {
//                    Console.WriteLine(  "Candidate Selected");
//                }
//                else
//                {
//                    Console.WriteLine("Candidate not selected");
//                }
//            }
//                else
//                {
//                Console.WriteLine("Not clear pre");
//                }
//            Console.ReadKey();
//        }

//    }
//}
