﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace FirstApp
//{
//    class BoxingUnBoxing
//    {
//        public static void Main()
//        {
//            int num=25;//Value Type
//            object myOb;//Reference Type
//            myOb = num;//Boxing 

//            Console.WriteLine("Boxed Value : \t "+myOb);
//            int num2;//Value Type
//            num2 = (int) myOb; //UnBoxing 
//            Console.WriteLine("UnBoxed Value : "+num2);
           
//            Console.ReadKey();

//            //Use ....goto to do this task
//            //Take the userName from user , userName must have at least six characters
//            //If username not have six characters , Invalid User Name message line comes
//            //Progarm ask you again to enter user Name
//        }
//    }
//}
