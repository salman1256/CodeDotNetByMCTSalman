﻿//using System;
//namespace FirstApp
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            //Console.WriteLine("Welcome to C#");
//            //Console.WriteLine("Welcome to C# Again");
//            //Console.Write("Welcome to C#  by Write");
//            //Console.Write("Welcome to C# Again by Write");
//            //DataType variableName;

//            //string userName;
//            //Console.WriteLine("Enter User Name");
//            //userName = Console.ReadLine();
//            //Console.WriteLine("Welcome Mr.\\Ms. \t"+userName);

//            //DataType.Parse()
//            //int.Parse

//            //int rollNo;
//            //Console.WriteLine("Enter Roll Number");
//            //rollNo = int.Parse(Console.ReadLine());
//            //Console.WriteLine("Student Roll Number is "+rollNo);


//            //Console.ReadKey();

//            //string fName, lName;
//            //int age,roll;
//            //char grade;
//            //double fee;
//            //Console.WriteLine("Enter Student\'s Roll Number");
//            //roll = int.Parse(Console.ReadLine());
//            //Console.WriteLine("Enter Student\'s First Name");
//            //fName = Console.ReadLine();
//            //Console.WriteLine("Enter Student\'s Last Name");
//            //lName = Console.ReadLine();
//            //Console.WriteLine("Enter Student\'s Age");
//            //age = int.Parse(Console.ReadLine());
//            //Console.WriteLine("Enter Student\'s Grade");
//            //grade = char.Parse(Console.ReadLine());
//            //Console.WriteLine("Enter Student\'s Fee");
//            //fee = double.Parse(Console.ReadLine());
//            ////Console.WriteLine("Student\'s Details as follows");
//            ////Console.WriteLine("Name: \t"+fName+' '+lName);
//            ////Console.WriteLine("Roll: \t" +roll);
//            ////Console.WriteLine("Age: \t" +age);
//            ////Console.WriteLine("Grade: \t" +grade);
//            ////Console.WriteLine("Fee: \t" +fee);
//            ////Console.WriteLine("Student\'s Details as follows");
//            //// Console.WriteLine(" Name: \t" + fName + ' '   + lName+ "\n Roll: \t"
//            ////+ roll + "\n Age: \t" + age
//            ////+ "\n Grade: \t" + grade
//            ////+ "\n Fee: \t" + fee);
//            //Console.WriteLine
//            //("Welcome Mr.\\ Ms. {1} \n Your Details as follows \n First Name: \t {0} \n Last Name: {1}" +
//            //"\n Roll:  {2} \n Age: {3} \n Grade: {4} \n Fee: {5}",
//            //fName,lName,roll,age,grade,fee);         

            
//            //Console.ReadKey();




//        }
//    }
//}
