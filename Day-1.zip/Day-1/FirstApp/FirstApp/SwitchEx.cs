﻿//using System;
//namespace FirstApp
//{
//   public class SwitchEx
//    {
//        public static void Main()
//        {
//            int num;
//            object m;
//            string cCode, lang;
//            string choice="n";
//            do {
//                Console.WriteLine("Enter cCode to  find languange");
//                cCode = Console.ReadLine().ToLower();
//                switch (cCode)
//                {
//                    case "in":
//                    {
//                            lang = "Hindi,English,Urdu,Punjabi";
//                            break; }
//                    case "uk":
//                    case "us":
//                        {
//                            lang = "English";
//                            break; }
//                    case "uae":
//                    case "egypt":
//                     case "om":
//                    case "ksa":
//                        {
//                            lang = "Arabic";
//                            break; }
//                    default:
//                        {
//                            Console.WriteLine("You country is not registered with us");
//                            lang = "not found";
//                            break; }
//                }
//                Console.WriteLine("Country Code: \t {0} \nLanguage(s): \t {1}",cCode.ToUpper(),lang.ToUpper());



//                Console.WriteLine("Do you wanna continue? if yes Press y");
//                choice = Console.ReadLine().ToLower();
//            }
//            while (choice=="y");
//        }
//    }
//}
