﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstApp
{
    class SingleDimArray
    {
        public static void Main()
        {
            //int nos;
            //Console.WriteLine("Enter Number of Students");
            //nos = int.Parse(Console.ReadLine());
            //string[] students = new string[nos];
            //for (int i = 0; i < nos; i++)
            //{
            //    Console.WriteLine("Enter Student{0}\'s Name",(i+1));
            //    students[i] = Console.ReadLine();
            //}
            //Console.WriteLine("-----Students List ----");
            //for (int i = 0; i < nos; i++)
            //{
            //    Console.WriteLine("Student{0}\'s Name = \t {1}", (i + 1), students[i]);

            //}
            //int nos;
            //Console.WriteLine("Enter Number of Students");
            //nos = int.Parse(Console.ReadLine());
            //string[] students = new string[nos];
            //for (int i = 0; i < nos; i++)
            //{
            //    Console.WriteLine("Enter Student{0}\'s Name", (i + 1));
            //    students[i] = Console.ReadLine();
            //}
            ////foreach(DataType Identifier in CollectionName) {//Body of Loop}
            //Console.WriteLine("-----Students List ----");
            //foreach (string n in students)
            //{
            //    Console.WriteLine(n);
            //}

            //Console.ReadKey();

            // var myVar = 'c';
            //Console.WriteLine("Value store Inside myVar is: {0} \n  Data Type is : {1} "
            //     ,myVar,myVar.GetType());
            dynamic[] myArray = { 12, 45, 67, 89,"Sam",'a',9000.90,new DateTime(day:12,month:10,year:2012) };
            foreach (var el in myArray)
            { Console.WriteLine(el); }
            Console.ReadKey();
        }
    }
}
