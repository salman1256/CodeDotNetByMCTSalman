﻿//using System;
//using System.Threading;

//namespace ConAppThreadType
//{
//    public class MyClass
//    {
//        public static void JobOne()
//        {
//            Console.WriteLine("Job Started!!! It's going to print 1-10 in 5 Seconds");
//            for (int i = 1; i <= 10; i++)
//            {
//                Console.WriteLine("Number : {0}", i);
//                Thread.Sleep(200);

//            }
//            Console.WriteLine("End of Task");
//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Thread objt = new Thread(MyClass.JobOne);
//            objt.Start();
//            Console.WriteLine("End of Main Thread!!!");
//        }
//    }
//}
//using System;
//using System.Threading;

//namespace ConAppThreadType
//{
//    public class MyClass
//    {
//        public static void JobOne()
//        {
//            Console.WriteLine("Job Started!!! It's going to print 1-10 in 5 Seconds");
//            for (int i = 1; i <= 10; i++)
//            {
//                Console.WriteLine("Number : {0}", i);
//                //Thread.Sleep(200);

//            }
//            Console.WriteLine("End of Task");
//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Thread objt = new Thread(MyClass.JobOne)
//            {
//                IsBackground = true
//            };
//            objt.Start();
//            Console.WriteLine("End of Main Thread!!!");
//        }
//    }
//}
//Example-3
using ConAppThreadType;
using System;
using System.Threading;
namespace ThreadingExampleThree
{
    public class Program
    { public static void Display(object myob)
        {
            for (int i = 1; i < 10; i++)
            {
                Console.WriteLine("Value of i" + i);
                Thread.Sleep(2000);
            }
        } 
public static void BgTaskWObject(object stateInfo)
        {
            Emp myEmp = (Emp)stateInfo;
            Console.WriteLine("Welcome Mr.\\Ms. from ThreadPoll \t ",myEmp.EName);
            Thread.Sleep(2000);
            Console.WriteLine("Details as follows!!!");
            Console.WriteLine("ID: \t"+myEmp.EId);
            Console.WriteLine("Name: \t "+myEmp.EName);
            Console.WriteLine("Designation: \t"+myEmp.EDesig);
        }
        
        static void Main(string[] args)
        {
            //ThreadPool
           
            Thread mythread = new Thread(Display)
            {
                IsBackground = true
            };
            mythread.Start();
            Emp emp = new Emp(101, "Sam", "Manager!!!");
            //ThreadPool.QueueUserWorkItem(Display);
            ThreadPool.QueueUserWorkItem(BgTaskWObject, emp);
            
            Console.ReadKey();
        }
       
    }
}