﻿using System.Threading;


namespace ConAppThreadType
{
    public class Emp
    {
        int id;
        string name;
        string desig;
        public int EId{ get=>id; set=>id=value; } //public int EId { get{return id;} set{id=value;} }
        public string EName { get=>name; set=>name=value; }
        public string EDesig { get=>desig; set=>desig=value; }
        public Emp(int id,string name,string desig)
        {
            Thread.Sleep(5000);
            this.id = id;
            this.name = name;
            this.desig = desig;

        }
    }
}
