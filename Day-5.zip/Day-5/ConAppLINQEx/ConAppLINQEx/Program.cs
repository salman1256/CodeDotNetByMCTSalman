﻿//Query Syntax
//using System;
//using System.Collections.Generic;
//using System.Linq;


//namespace ConAppLINQEx
//{
//    class Program
//    {
//        static void Main(string[] args)

//        {    //Example-One
//            //string[] studNames = new string[] 
//            //{"Sam","Amit","Vinod","Firoz","Rohan","Neha","Zoya","Arihant" };
//            ////var QueryResult=from qvar in CollectionName where condition
//            //var names = from anames in studNames where anames.Contains('r') select anames;
//            //foreach (var name in names)
//            //{ Console.WriteLine(name); }
//            //Console.ReadKey();

//            //Example-2

//            //int[] numbers = new int[] { 12, 34, 33, 10, 9, 45, 47, 98, 1000, 34, 20, 21, 56 };
//            //var eveNumbers = from nums in numbers orderby nums descending where nums % 2 == 0 select nums;
//            //Console.WriteLine("**Even Numbers in Descending  order***");
//            //foreach (var n in eveNumbers)
//            //{
//            //    Console.WriteLine(n);
//            //}
//            //Console.ReadKey();
//            //Example-Three
//            //List<Emp> listEmps = new List<Emp>
//            //{
//            //     new Emp{ Id=5,Name="Amit",Designation="Manager",Salary=98000.99,
//            //    DOJ=new DateTime(day:22,month:10,year:2020)} ,
//            //      new Emp{ Id=30,Name="Zoya",Designation="Developer",Salary=68000.99,
//            //    DOJ=new DateTime(day:30,month:12,year:2019)},
//            //       new Emp{ Id=4,Name="Neha",Designation="Developer",Salary=68000.88,
//            //    DOJ=new DateTime(day:12,month:09,year:2020)},
//            //        new Emp{ Id=20,Name="Arun",Designation="Tester",Salary=75000.505,
//            //    DOJ=new DateTime(day:25,month:02,year:2021)},

//            //};
//            //Console.WriteLine("-------------List of Employees------------");
//            //foreach (var emp in listEmps)
//            //{
//            //    Console.Write(emp.Id + "\t");
//            //    Console.Write(emp.Name + "\t");
//            //    Console.Write(emp.Designation + "\t");
//            //    Console.Write(emp.Salary + "\t");
//            //    Console.Write(emp.DOJ.ToShortDateString() + "\t");
//            //    Console.WriteLine("\n");
//            //}
//            //var empListById = from emps in listEmps orderby emps.Name select emps;
//            //Console.WriteLine("Order By Employee Name");
//            //Console.WriteLine("ID \t Name \t Designation \t Salary \t Date of Joining");
//            //foreach (var emp in empListById)
//            //{
//            //    Console.Write(emp.Id +"\t");
//            //    Console.Write(emp.Name + "\t");
//            //    Console.Write(emp.Designation + "\t");
//            //    Console.Write(emp.Salary + "\t");
//            //    Console.Write(emp.DOJ.ToShortDateString() + "\t");
//            //    Console.WriteLine("\n");
//            //}
//            //Console.ReadKey();
//        }
//    }
//}

//Method Syntax
using System;
using System.Collections.Generic;
using System.Linq;
namespace ConAppLINQEx
{
    class Program
    {
        static void Main(string[] args)

        {    //Example-One
            //string[] studNames = new string[]
            //{"Sam","Amit","Vinod","Firoz","Rohan","Neha","Zoya","Arihant" };

            ////var names = from anames in studNames where anames.Contains('r') select anames;

            //var names = studNames.Where(n => n.Contains('r'));
            //foreach (var name in names)
            //{ Console.WriteLine(name); }
            //Console.ReadKey();

            //Example-2

            //int[] numbers = new int[] { 12, 34, 33, 10, 9, 45, 47, 98, 1000, 34, 20, 21, 56 };
            ////var eveNumbers = from nums in numbers orderby nums descending where nums % 2 == 0 select nums;
            //// var evenNumbers = numbers.Where(n => n % 2 == 0).OrderByDescending(n => n);
            //var evenNumbers = numbers.Where(n => n % 2 == 0).OrderBy(n => n);
            //Console.WriteLine("**Even Numbers in ASC  order***");
            //foreach (var n in evenNumbers)
            //{
            //    Console.WriteLine(n);
            //}
            //Console.ReadKey();
            //int[] numbers = new int[] { 12, 34, 33, 10, 9, 45, 47, 98, 1000, 34, 20, 21, 56 };
            ////var eveNumbers = from nums in numbers orderby nums descending where nums % 2 == 0 select nums;
            //// var evenNumbers = numbers.Where(n => n % 2 == 0).OrderByDescending(n => n);
            //var oddNumbers = numbers.Where(on => on% 2 == 1).OrderBy(on => on);
            //Console.WriteLine("**Even Numbers in ASC  order***");
            //foreach (var n in oddNumbers)
            //{
            //    Console.WriteLine(n);
            //}
            //Console.ReadKey();


           // Example - Three
            List<Emp> listEmps = new List<Emp>
            {
                 new Emp{ Id=5,Name="Amit",Designation="Manager",Salary=98000.99,
                DOJ=new DateTime(day:22,month:10,year:2020)} ,
                  new Emp{ Id=30,Name="Zoya",Designation="Developer",Salary=68000.99,
                DOJ=new DateTime(day:30,month:12,year:2019)},
                   new Emp{ Id=4,Name="Neha",Designation="Developer",Salary=68000.88,
                DOJ=new DateTime(day:12,month:09,year:2020)},
                    new Emp{ Id=20,Name="Arun",Designation="Tester",Salary=75000.505,
                DOJ=new DateTime(day:25,month:02,year:2021)},

            };
            Console.WriteLine("-------------List of Employees------------");
            foreach (var emp in listEmps)
            {
                Console.Write(emp.Id + "\t");
                Console.Write(emp.Name + "\t");
                Console.Write(emp.Designation + "\t");
                Console.Write(emp.Salary + "\t");
                Console.Write(emp.DOJ.ToShortDateString() + "\t");
                Console.WriteLine("\n");
            }
            //var empListById = from emps in listEmps orderby emps.Name select emps;
            var empListById = listEmps.OrderByDescending(e=>e.Name);
            Console.WriteLine("Order By Employee Name");
            Console.WriteLine("ID \t Name \t Designation \t Salary \t Date of Joining");
            foreach (var emp in empListById)
            {
                Console.Write(emp.Id + "\t");
                Console.Write(emp.Name + "\t");
                Console.Write(emp.Designation + "\t");
                Console.Write(emp.Salary + "\t");
                Console.Write(emp.DOJ.ToShortDateString() + "\t");
                Console.WriteLine("\n");
            }
            Console.ReadKey();
        }
    }
}
