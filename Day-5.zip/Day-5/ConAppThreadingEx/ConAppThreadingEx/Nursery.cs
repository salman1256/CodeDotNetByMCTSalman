﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

//namespace ConAppThreadingEx
//{
//    public class Nursery
//    {
//        public static void Tables()
//        {

//            for (int i = 1; i < 10; i++)
//            {
//                Console.WriteLine("{0} * {1} = \t {2}",i,5, (i*5));
//            }
//        }
//         public enum DayofWeek
//            {Sun,Mon,Tue,Wed,Thu,Fri,Sat}
//        public static void Display()
//        {
//            Console.WriteLine("Monday is {0} Day of Week  ", DayofWeek.Mon);
//        }
//        public static void Numbers()
//        {
//            for (int i = 0; i < 100; i++)
//            {
//                Console.WriteLine(i);
//            }
//        }
//    }
//}

//Example-Two
namespace ConAppThreadingEx
{
    public class Nursery
    {
        public static void Tables()
        {
            Console.WriteLine("Enter a number to find out table");
            int num = int.Parse(Console.ReadLine());

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0} * {1} = \t {2}", i, num, (i * num));
            }
        }
        public enum DayofWeek
        { Sun, Mon, Tue, Wed, Thu, Fri, Sat }
        public static void Display()
        {
            Console.WriteLine("Monday is {0} Day of Week  ", DayofWeek.Mon);
        }
        public static void Numbers()
        {
            for (int i = 0; i < 100; i++)
            {
                Console.Write(i+"\t");
               Thread.Sleep(1000);
            }
        }
    }
}