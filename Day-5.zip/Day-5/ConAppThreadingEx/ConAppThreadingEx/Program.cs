﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading;
//using System.Threading.Tasks;

//namespace ConAppThreadingEx
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            //Nursery.Numbers();//Task1
//            //Nursery.Display(); //Task2
//            //Nursery.Tables(); //Task3
//            //Console.ReadKey();
//            Thread thread1 = new Thread(Nursery.Numbers);
//            Thread thread2 = new Thread(Nursery.Tables);
//            Thread thread3 = new Thread(Nursery.Display);
//            thread1.Start();
//            thread2.Start();
//            thread3.Start();
//            Console.ReadKey();
//        }
//    }
//}

//Example-two

using System;
using System.Threading;

namespace ConAppThreadingEx
{
    class Program
    {
        static void Main(string[] args)
        {
            //Nursery.Numbers();//Task1
            //Nursery.Display(); //Task2
            //Nursery.Tables(); //Task3
            //Console.ReadKey();
            Thread thread1 = new Thread(Nursery.Tables);
            Thread thread2 = new Thread(Nursery.Numbers);
            Thread thread3 = new Thread(Nursery.Display);
            thread2.Start();
            thread2.Join();
            thread1.Start();
            thread1.Join();
            thread3.Start();
            Console.ReadKey();
        }
    }
}