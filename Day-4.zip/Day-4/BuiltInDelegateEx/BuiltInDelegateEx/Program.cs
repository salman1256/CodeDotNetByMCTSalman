﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuiltInDelegateEx
{
    class Program
    {
        static void Main(string[] args)
        {
            //Func<double, double, double> addDel = Calc.Add;
            //Console.WriteLine("Enter First Number");
            //double n1 = double.Parse(Console.ReadLine());
            //Console.WriteLine("Enter Second Number");
            //double n2 = double.Parse(Console.ReadLine());
            //double res = addDel(n1, n2);
            //Console.WriteLine("Result\t "+res);
            //Func<string, string, string, string> details = Calc.Address;
            //Console.WriteLine(details("Raj","Kumar Wahi","Mumbai"));
            //Console.ReadKey();

            //Exercise: 
            //Call similar methods using Func & lambda Expression
            //Action<double, double> addition = (p1, p2) => Console.WriteLine("Result \t "+p1+p2);
            //addition(12.45, 45.45);
            //Action<double, double> action = Calc.Add;
            // action(12.56, 12.56);
            //Console.ReadKey();
            // Predicate
            Predicate<int> predicate = Voters.IsVoter;
            Console.WriteLine("Enter Your Age");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("Eligible for Voting : "+predicate(age));
            Console.ReadKey();

            //Func
            //Action
            //Predicate

        }
       
    }
    public static class Voters
    {
        public static bool IsVoter(int age)
        {
            if (age >= 18)
            { return true; }
            else
            {
                return false;
            }
        }
    }
    public class Calc
    {
        public static void Add(double num1, double num2)
        {
            Console.WriteLine("Result after adding {0} and {1}= \t {2}",num1,num2, num1 + num2);
             
        }
        //public static double Add(double num1, double num2)
        //{
        //    return num1 + num2;
        //}
        public static string Address(string fn, string ln,string city)
        {
            return "FullName:-> "+ fn +" "+ ln+ "City:-> "+city;
        }
    }
}
