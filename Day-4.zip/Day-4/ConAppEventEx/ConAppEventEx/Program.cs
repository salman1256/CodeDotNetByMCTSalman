﻿using System;
using System.Collections.Generic;
namespace ConAppEventEx
{
    public delegate void MyDel(double n1, double n2);
   
    class Program
    {
        static void Main(string[] args)
        {
            MyClass my = new MyClass();
            MyClass.MyEvent += new MyDel(my.Sub);
           MyClass. MyEvent += new MyDel(my.Div);
            my.RaiseEvent(12, 45);
            MyClass.MyEvent -= new MyDel(my.Div);
            Console.WriteLine("Raising Event after Removing Div");
            my.RaiseEvent(12, 45);
            Console.ReadKey();
        }
    }
    public class MyClass
    {
        public static event MyDel MyEvent;

        public void RaiseEvent(double n1, double n2)
        {
            MyEvent(n1, n2);
            Console.WriteLine("Event Generated!!!");
        }
        public void Add(double num1, double num2)
        {
            Console.WriteLine("Result after Adding {0} and {1} \t ={2}",num1,num2,(num1+num2));
        }
        public void Sub(double num1, double num2)
        {
            Console.WriteLine("Result after Subtracting {0} from {1} \t ={2}", num1, num2, (num2- num1));
        }
        public void Multi(double num1, double num2)
        {
            Console.WriteLine("Result after Multiplying {0} and {1} \t ={2}", num1, num2, (num1 * num2));
        }
        public void Div(double num1, double num2)
        {
            Console.WriteLine("Result after Dividing {0} by {1} \t ={2}", num1, num2, (num1/ num2));
        }
    }
}
