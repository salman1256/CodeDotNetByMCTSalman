﻿using System;
using MathLib;
namespace DelegatesExampleTwo
{
    public delegate void CalcDel(double n1,double n2);
    public class Program
    {
        static void Main(string[] args)
        {
            Calc calc = new Calc();
           
            CalcDel del = new CalcDel(calc.Add);
            Console.WriteLine("Result after adding only one Method");
            del(12.45, 12.45);
            del += new CalcDel(calc.Sub);
            del += new CalcDel(calc.Add);
            del += new CalcDel(calc.Div);
            del += new CalcDel(calc.Multi);
            Console.WriteLine("Result after adding 5 Methods");
            del(12.45, 12.45);

            del -= new CalcDel(calc.Sub);
            del -= new CalcDel(calc.Add);
            Console.WriteLine("Result after removing 2 Methods");
            del(12.45, 12.45);
            Console.ReadKey();
        }
    }
}
