﻿using System;
namespace MathLib
{
    public class Calc
    {
        public void Add(double n1, double n2)
        {
            double result = n1 + n2;
            Console.WriteLine("Result after adding {0} and {1} =\t {2} ",n1,n2,result);
        }
        public void Sub(double n1, double n2)
        {
            double result = n1 - n2;
            Console.WriteLine("Result after subtracting {0} and {1} =\t {2} ", n1,n2,result);
        }
        public void Multi(double n1, double n2)
        {
            double result = n1 * n2;
            Console.WriteLine("Result after Multipliying {0} and {1} =\t {2} ",n1,n2, result);
        }
        public void Div(double n1, double n2)
        {
            double result = n1 / n2;
            Console.WriteLine("Result after Dividing {0} by {1} =\t {2} ",n1,n2, result);
        }
        public void Avg(double n1, double n2)
        {
            double result = (n1 +n2)/2;
            Console.WriteLine("Average of {0} and {1} =\t {2} ",n1,n2, result);
        }
    }
}
