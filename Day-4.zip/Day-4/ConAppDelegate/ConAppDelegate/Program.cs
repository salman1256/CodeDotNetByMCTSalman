﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ConAppDelegate
//{
//    public delegate void OurDel(string name);
//    public class OurClass
//    {
//        public static void Welcome(string userName)
//        {
//            Console.WriteLine("Welcome to Delegates in C# Mr.\\Ms. \t  "+userName);
//        }
//        public void Display(string msg)
//        {
//            Console.WriteLine("Message For You: "+msg);
//        }
//        public void CheckValidity(string parm,string param2)
//        {
//            Console.WriteLine( "Is it valid or not?"+parm);
//        }
//    }
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            //OurDel del = new OurDel(OurClass.Welcome);
//            //Console.WriteLine("Enter User Name");
//            //del(Console.ReadLine());
//            //OurClass our = new OurClass();
//            //OurDel objDel = new OurDel(our.Display);
//            //Console.WriteLine("Enter Your Message");
//            //objDel(Console.ReadLine());

//        }
//    }
//}
using ConAppDelegate;
using System;
namespace DelegateExampleTwo
{
    public delegate double CalcDel(double num1, double num2);
    public class MyClass
    {
        public static void Main()
        {
            try
            {
                CalcDel del = new CalcDel(Calculation.Add);
                Console.WriteLine("Enter First Number");
                double num1 = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter Second Number");
                double num2 = double.Parse(Console.ReadLine());
                double res = del(num1, num2);
                Console.WriteLine("Result after adding {0} and {1} =\t {2}", num1, num2, res);
            }
            catch (FormatException fe)
            {
                Console.WriteLine("Use Correct DataType!!!");
                Console.WriteLine("System Message!! " + fe.Message);
            }
            catch (Exception ex)
            { Console.WriteLine("Exception Occured!!! " + ex.Message); }
           
            finally
            {
                Console.ReadKey();
            }
        }
    }

}