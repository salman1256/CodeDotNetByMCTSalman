﻿using System;

namespace ConAppDelegate
{
   public class Calculation
    {
        public static double Add(double n1, double n2)
        {
            return n1 + n2;
        }
    }
}
