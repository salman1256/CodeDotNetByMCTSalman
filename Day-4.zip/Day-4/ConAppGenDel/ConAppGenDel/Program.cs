﻿using System;
namespace ConAppGenDel
{
    public delegate T MyGenDel<T> (T t1, T t2);
    class Program
    {
        static void Main(string[] args)
        {
            Emp emp = new Emp();
            MyGenDel<string> del = emp.EmpFullName;
            Console.WriteLine("Calling Generic Delegate With String");
            Console.WriteLine(del("Sam","Dicosta"));
            MyGenDel<double> del2 = emp.InHandSalary;
            Console.WriteLine("Calling Generic Delegate With double");
            Console.WriteLine("In Hand Salary = \t " + del2(20000.90, 0.10));
            Console.ReadKey();
        }
    }
}
public class Emp
{ 
    public  string EmpFullName(string fName, string lName)
    {
        return fName + ' ' + lName;
    }
    public  double InHandSalary(double netSal, double tax)
    {
        return netSal - (netSal * tax);

    }
}
