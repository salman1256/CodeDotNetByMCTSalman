﻿namespace LambdasEx2
{
    internal class Emp
    {
        public int EId{ get; set; }
        public  string EName { get; set; }
        public string EDesig { get; set; }
        public int EYExp { get; set; }
    }
}