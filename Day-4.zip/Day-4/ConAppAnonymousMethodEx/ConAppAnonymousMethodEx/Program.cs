﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace ConAppAnonymousMethodEx
//{
//    public delegate void MyDel(string name);
//    class Program
//    {
//        static void Main(string[] args)
//        {


//            MyDel del = delegate (string name)
//             {
//                 Console.WriteLine("Welcome to Anonymous Methods Mr.\\Ms. " + name);
//             };
//            Console.WriteLine("Enter User Name");

//            del(Console.ReadLine());
//            Console.ReadKey();
//        }
//    }
//}

//namespace ConAppAnonymousMethodEx
//{
//    public delegate void MyDel(string name);
//    class Program
//    {
//        static void Main(string[] args)
//        {


//            MyDel del = n => { Console.WriteLine("Welcome to Lambdas : " + n); };
//            Console.WriteLine("Enter User Name");

//            del(Console.ReadLine());
//            Console.ReadKey();
//        }
//    }
//}
namespace LambdasEx2
{
    delegate bool DelSeniorityCheck(Emp emp);
    public class MyClass
    {
        public static void Main()
        {
            DelSeniorityCheck delSeniority = e => e.EYExp >= 20;
            Emp emp = new Emp { EId = 1, EName = "Sam", EDesig = "Manager", EYExp = 32 };
            if (delSeniority(emp))
            {
                Console.WriteLine("Senior Employee Details as follows!!!");
                Console.WriteLine("ID: " + emp.EId);
                Console.WriteLine("Name: " + emp.EName);
                Console.WriteLine("Designation: " + emp.EDesig);
                Console.WriteLine("Year of Experience: " + emp.EYExp);
            }
            else {
                Console.WriteLine(emp.EName +" Not full fill the requirement ");
            }
            Console.ReadKey();
        }
    }
}