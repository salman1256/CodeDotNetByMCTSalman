﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConAppIndexer
{  //[AS][Mod] returnType PropertyName {get {}set{}}
   //[AS] retrurnType this [parameters]{get{}set{}}
    public class Emp
    {
        string[] myArr = new string[5];
        public string this[int index]
        {
            get { return myArr[index]; }
            set { myArr[index] = value; }
        }
        
    }
    class Program
    {
        static void Main(string[] args)
        {
            Emp emp = new Emp();
            emp[0] = "Ravi";
            emp[1] = "Mahesh";
            emp[2] = "Jai";
            emp[3] = "Raj";
            emp[4] = "Neha";
            
            for (int i = 0; i < 5; i++)
            { Console.WriteLine(emp[i]); }
            Console.ReadKey();
        }
    }
}
