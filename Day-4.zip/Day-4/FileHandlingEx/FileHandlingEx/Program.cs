﻿using System;
using System.IO;

namespace FileHandlingEx
{
    class Program
    {
        static void Main(string[] args)
        {
            //File;
            //string path = "D:\\Xebia-B-1\\Day-4\\OurFiles\\SamDoc.txt";
            //if (File.Exists(path))
            //{
            //    string filetext = File.ReadAllText(path);
            //    Console.WriteLine(filetext);
            //}
            //else { Console.WriteLine("No Such File Exists!!!"); }
            //try
            //{
            //    string path = "D:\\Xebia-B-1\\Day-4\\OurFiles\\";
            //    string fileName;
            //    Console.WriteLine("Enter File Name to Create File");
            //    fileName = Console.ReadLine();
            //    if (File.Exists(path + fileName))
            //    { Console.WriteLine("Alread Exist!!!"); }
            //    else
            //    {
            //        File.Create(path + fileName);
            //        Console.WriteLine("File Created!!!");
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine("Error!!!" + ex.Message);
            //}
            //finally
            //{
            //    Console.ReadKey();
            //}
            //try
            //{
            //    string path = "D:\\Xebia-B-1\\Day-4\\OurFiles\\";
            //    string fileName;
            //    Console.WriteLine("Enter File Name to Delete File");
            //    fileName = Console.ReadLine();
            //    string cPath = path + fileName;
            //    if (File.Exists(cPath))
            //    {
            //        File.Delete(cPath);
            //        Console.WriteLine("File Deleted Permanently!!!"); }
            //    else
            //    {

            //        Console.WriteLine("No such File {0} exist !!!",fileName);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine("Error!!!" + ex.Message);
            //}
            //finally
            //{
            //    Console.ReadKey();
            //}
            //try
            //{
            //    string path = "D:\\";
            //    Console.WriteLine("Enter Directory to Create!!!");
            //    string subDir = Console.ReadLine();
            //    string cPath = path + subDir;
            //    if (Directory.Exists(cPath))
            //    {
            //        Console.WriteLine("This Folder " + subDir + "is already exist!!!");
            //    }
            //    else
            //    {
            //        Directory.CreateDirectory(cPath);
            //        Console.WriteLine("Folder Created !!!");
            //        Console.WriteLine();
            //    }
            //}
            //catch (Exception ex)
            //{ Console.WriteLine(ex.Message); }
            //finally { Console.ReadKey(); }
            try
            {
                string path = "D:\\";
                DirectoryInfo di = new DirectoryInfo(path);
                DirectoryInfo[] directories = di.GetDirectories();
                int i = 1;
                foreach (DirectoryInfo directory in directories)
                {
                    Console.WriteLine("File No: {0} is \t {1} ", i, directory.FullName);
                    Console.WriteLine("");
                    i++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.ReadKey();
            }

        }
    }
}
